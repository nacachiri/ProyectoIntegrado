Hola,

Para entrar al proyecto utiliza coinfuel.ddns.net.
Recordamos que es obligatorio su registro para entrar en la aplicación.

Si vas ha abrir el código en local tendrás que cambiar alguna de las rutas,
y además modificar el archivo de conf.csv.

Salu2

By ProyectoAlfa Coinfuel