<?php

    require_once 'autoload.php';

    $gasolineras = new gasolinera();

    $gasolineras->importar();

?>