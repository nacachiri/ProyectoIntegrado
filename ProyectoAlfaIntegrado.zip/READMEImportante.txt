Hola,

Si vas ha abrir el codigo en local tendras que cambiar alguna de las rutas, 
y ademas modificar el archivo de conf.csv.

Salu2

By ProyectoAlfa Coinfuel